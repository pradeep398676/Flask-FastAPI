from flask import Flask, render_template, request, url_for, session
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///dummy.db"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

@app.route('/',methods=['GET','POST'])
def home():
    if request.method == 'POST':
        name = request.form.get('name')
        document = request.files.get('document')
        print(name, type(name))
        print(document, type(document))
    return render_template('index.html')

